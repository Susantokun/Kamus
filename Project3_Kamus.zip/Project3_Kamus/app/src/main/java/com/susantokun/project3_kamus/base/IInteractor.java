package com.susantokun.project3_kamus.base;

/**
 * Created by Susantokun on 11 November 2018
 */

public interface IInteractor<T> {

    T getPreferencesHelper();
}