package com.susantokun.project3_kamus.base.listener;

/**
 * Created by Susantokun on 11 November 2018
 */

public interface RecyclerViewItemClickListener {
    void onItemClick(int position);
}
