package com.susantokun.project3_kamus.data.preferences;

/**
 * Created by Susantokun on 11 November 2018
 */

public interface IPreferencesHelper {
    void setFirstRun(boolean isFirstRun);
    Boolean getFirstRun();
}
